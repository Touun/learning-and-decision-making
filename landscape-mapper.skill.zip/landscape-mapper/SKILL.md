---
name: landscape-mapper
description: >
  Visually map out the landscape of people, organizations, and relationships relevant to a
  decision or situation using a fully interactive, self-contained HTML/CSS/JS network diagram
  that opens instantly in any browser. Use this skill when someone wants to: "map this out for me",
  "show me who's connected", "I need to see the big picture", "draw the relationships", "stakeholder map",
  "who are the players?", create a relationship diagram, visualize dependencies between people or teams,
  see where the bottlenecks are, understand power dynamics, map a supply chain, chart organizational influence,
  identify key connectors or gatekeepers, or any time someone wants a visual network showing how entities
  (people, companies, teams, resources) connect to each other.
---

# Landscape Mapper

You are an AI that helps people visually map relationships and dependencies. Instead of static images or complex terminal tools, you produce a **fully interactive, self-contained HTML/CSS/JS web page** (e.g., `landscape_map.html`). When the user double-clicks this file, it opens a stunning, responsive, dark-mode network visualization in their web browser.

**Your role**: Extract entities and relationships from what the human tells you, structure the network, write the interactive HTML/CSS/JS code, save it to the workspace, and highlight what the map reveals.
**The human's role**: Provide the context — who is involved, how they are connected, and what question they are trying to answer.

---

## Core Mapping Concepts (Plain English)

| Concept | What it means | How it is represented in the Web UI |
| :--- | :--- | :--- |
| **Node** | An entity (person, company, team, resource) | Draggable, hoverable circles/shapes colored by type |
| **Edge / Link** | A relationship between two entities | Arrows showing flow direction; thickness shows connection strength |
| **Centrality** | How connected or powerful an entity is | Influences node size (more connected = larger node) |
| **Uncertainty** | A suspected or unconfirmed connection | Rendered as a dashed, semi-transparent line |
| **Bottlenecks** | Crucial bridges connecting separate groups | Highlighted via analytical side panels |

---

## Entity Types & Color System

To achieve a premium, unified aesthetic, nodes and relationships are mapped to a refined dark-theme color palette:

### Node Types
*   👤 **Person**: `#4A90E2` (Vibrant Blue) — Founders, investors, advisors, key hires.
*   🏢 **Organization**: `#7ED321` (Leaf Green) — Companies, agencies, departments, universities.
*   📍 **Location**: `#F5A623` (Warm Amber) — Offices, cities, regional markets.
*   📅 **Event**: `#D0021B` (Crimson) — Launches, funding rounds, deadlines.
*   ⚙️ **Resource**: `#9013FE` (Deep Purple) — Shared tools, budgets, core platforms.
*   💡 **Concept**: `#50E3C2` (Mint Turquoise) — Strategies, regulations, market trends.

### Connection Types
*   🟢 **funding**: `#2E7D32` (Green arrow) — Investment or budget flow.
*   🔵 **communication**: `#1565C0` (Blue arrow) — Reporting, syncs, active messaging.
*   🟠 **collaboration**: `#EF6C00` (Orange arrow) — Product integrations, partnerships, co-working.
*   🔴 **ownership**: `#B71C1C` (Red arrow) — Direct control or equity.
*   ⚫ **reports_to**: `#374151` (Dark gray arrow) — Structural reporting lines.
*   ⚪ **suspected**: `#9CA3AF` (Dashed arrow) — Unconfirmed rumors or potential relationships.

---

## How This Works — Step by Step

### Step 1 — Extract the Entities and Connections
From the human's description, extract:
1. **Nodes**: Entity names, their types, and roles.
2. **Edges**: From → To connections, relationship types, relative strength (1 to 3), and status (confirmed vs. suspected).
3. **Primary focus**: What is the core question or bottleneck the user wants to solve?

### Step 2 — Structure the Interactive Data
Organize the extracted data into JavaScript arrays representing `nodes` and `edges`. Calculate the **Degree Centrality** (number of connections) for each node to set the node's sizing factor.

### Step 3 — Generate the Self-Contained HTML File
Write a complete, beautiful HTML/CSS/JS file and save it in the workspace (e.g., `landscape-mapper/landscape_map.html` or `/Users/me/Desktop/empower/landscape_map.html`). 

The page uses **vis.js** (via a version-pinned CDN with automatic fallback) to handle dynamic force-directed physics, smooth panning/zooming, node dragging, and click interactions.

---

## The Interactive HTML/CSS/JS Template

When outputting the file, **always** use this premium, dark-mode, glassmorphic template. It includes a physics-simulation canvas, a collapsible sidebar displaying detailed node metrics on-click, and filter controls.

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Interactive Landscape Map</title>
  <!-- Load vis-network CDN (pinned version, with fallback) -->
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/vis-network/9.1.9/standalone/umd/vis-network.min.js"></script>
  <script>
    if (typeof vis === "undefined") {
      document.write('<script src="https://unpkg.com/vis-network@9.1.9/standalone/umd/vis-network.min.js"><\/script>');
    }
  </script>
  <!-- Import Outfit Google Font -->
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;800&display=swap" rel="stylesheet">
  
  <style>
    :root {
      --bg-dark: #0f172a;
      --panel-bg: rgba(30, 41, 59, 0.7);
      --border-color: rgba(255, 255, 255, 0.08);
      --text-main: #f8fafc;
      --text-sub: #94a3b8;
      --accent: #3b82f6;
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: 'Outfit', sans-serif;
      background-color: var(--bg-dark);
      color: var(--text-main);
      overflow: hidden;
      height: 100vh;
      display: flex;
    }

    /* Main visual canvas */
    #network-container {
      flex: 1;
      height: 100%;
      cursor: grab;
    }

    #network-container:active {
      cursor: grabbing;
    }

    /* Floating Header Panel */
    .header-panel {
      position: absolute;
      top: 20px;
      left: 20px;
      background: var(--panel-bg);
      backdrop-filter: blur(16px);
      border: 1px solid var(--border-color);
      border-radius: 16px;
      padding: 20px 24px;
      z-index: 10;
      max-width: 400px;
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.3);
    }

    .header-panel h1 {
      font-size: 20px;
      font-weight: 800;
      letter-spacing: -0.5px;
      margin-bottom: 6px;
      background: linear-gradient(135deg, #60a5fa, #3b82f6);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }

    .header-panel p {
      font-size: 13px;
      color: var(--text-sub);
      line-height: 1.5;
    }

    /* Right Glassmorphic Detail Panel */
    .detail-panel {
      width: 360px;
      height: 100%;
      background: var(--panel-bg);
      backdrop-filter: blur(20px);
      border-left: 1px solid var(--border-color);
      padding: 40px 24px;
      z-index: 10;
      display: flex;
      flex-direction: column;
      gap: 30px;
      box-shadow: -10px 0 30px rgba(0, 0, 0, 0.25);
      overflow-y: auto;
    }

    .panel-section h3 {
      font-size: 11px;
      font-weight: 800;
      text-transform: uppercase;
      letter-spacing: 1.5px;
      color: var(--accent);
      margin-bottom: 12px;
    }

    .node-details {
      display: flex;
      flex-direction: column;
      gap: 16px;
    }

    .node-name {
      font-size: 24px;
      font-weight: 600;
      letter-spacing: -0.5px;
    }

    .badge {
      display: inline-flex;
      align-items: center;
      padding: 6px 12px;
      border-radius: 20px;
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      width: fit-content;
    }

    .node-description {
      font-size: 14px;
      color: var(--text-sub);
      line-height: 1.6;
    }

    .connections-list {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    .connection-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 14px;
      background: rgba(255, 255, 255, 0.03);
      border: 1px solid var(--border-color);
      border-radius: 10px;
      font-size: 13px;
    }

    .connection-item .relation {
      font-size: 11px;
      color: var(--text-sub);
      text-transform: uppercase;
      font-weight: 600;
    }

    /* Floating Legend */
    .legend-panel {
      position: absolute;
      bottom: 20px;
      left: 20px;
      background: var(--panel-bg);
      backdrop-filter: blur(16px);
      border: 1px solid var(--border-color);
      border-radius: 16px;
      padding: 16px 20px;
      z-index: 10;
      display: flex;
      gap: 16px;
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.3);
    }

    .legend-item {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 12px;
      color: var(--text-sub);
    }

    .legend-dot {
      width: 10px;
      height: 10px;
      border-radius: 50%;
    }
  </style>
</head>
<body>

  <!-- Map Header -->
  <div class="header-panel">
    <h1 id="map-title">Stakeholder Landscape Map</h1>
    <p id="map-subtitle">Click and drag nodes to explore relationships. Click any entity to inspect its dependencies and network role.</p>
  </div>

  <!-- Legend -->
  <div class="legend-panel" id="legend">
    <!-- Legends are generated dynamically by script -->
  </div>

  <!-- Interactive Canvas -->
  <div id="network-container"></div>

  <!-- Side Inspector Panel -->
  <div class="detail-panel">
    <div class="panel-section">
      <h3>Entity Profile</h3>
      <div class="node-details" id="profile-section">
        <div class="node-name" id="selected-name">Select an Entity</div>
        <div id="selected-type-badge"></div>
        <div class="node-description" id="selected-desc">Click any node in the landscape diagram to reveal its connections, role, and details here in the side inspector.</div>
      </div>
    </div>

    <div class="panel-section">
      <h3>Network Connections</h3>
      <div class="connections-list" id="selected-connections">
        <!-- Node connections populated dynamically -->
      </div>
    </div>
  </div>

  <script>
    // 1. Core Data Mapped from Human Context
    const nodeData = [
      { id: 1, label: "Alice", group: "Person", title: "Founder & Product Lead", value: 3, desc: "Alice is the founder driving product development and managing the core engineering team." },
      { id: 2, label: "Bob", group: "Person", title: "Key Technical Advisor", value: 2, desc: "Bob provides architectural oversight and acts as a bridge to potential strategic partners." },
      { id: 3, label: "Acme Corp", group: "Organization", title: "Primary Enterprise Customer", value: 4, desc: "Acme Corp is the anchor enterprise client accounting for 60% of recurring revenue." },
      { id: 4, label: "Beta Inc", group: "Organization", title: "Lead Seed Investor", value: 2, desc: "Beta Inc led the seed investment round and holds a board observer seat." },
      { id: 5, label: "Dev Team", group: "Organization", title: "Internal Core Developers", value: 2, desc: "The engineering team responsible for sprint delivery and technical scalability." }
    ];

    const edgeData = [
      { from: 1, to: 3, label: "collaboration", value: 3, status: "confirmed", color: "#EF6C00" },
      { from: 1, to: 5, label: "reports_to", value: 3, status: "confirmed", color: "#374151" },
      { from: 2, to: 1, label: "communication", value: 2, status: "confirmed", color: "#1565C0" },
      { from: 4, to: 3, label: "funding", value: 3, status: "confirmed", color: "#2E7D32" },
      { from: 1, to: 2, label: "communication", value: 1, status: "suspected", color: "#9CA3AF", dashes: true }
    ];

    // Colors mapping
    const colors = {
      "Person": "#4A90E2",
      "Organization": "#7ED321",
      "Location": "#F5A623",
      "Event": "#D0021B",
      "Resource": "#9013FE",
      "Concept": "#50E3C2"
    };

    // 2. Generate the Legend
    const legendContainer = document.getElementById("legend");
    const activeGroups = [...new Set(nodeData.map(n => n.group))];
    activeGroups.forEach(group => {
      const item = document.createElement("div");
      item.className = "legend-item";
      item.innerHTML = `<span class="legend-dot" style="background:${colors[group]}"></span>${group}`;
      legendContainer.appendChild(item);
    });

    // 3. Prepare Vis datasets
    const nodes = new vis.DataSet(nodeData.map(node => ({
      ...node,
      color: {
        background: colors[node.group] || "#94a3b8",
        border: "rgba(255, 255, 255, 0.15)",
        highlight: {
          background: colors[node.group] || "#94a3b8",
          border: "#ffffff"
        }
      },
      font: { color: "#ffffff", face: "Outfit", size: 14, strokeWidth: 2, strokeColor: "#0f172a" },
      shape: "dot",
      scaling: { min: 15, max: 40 }
    })));

    const edges = new vis.DataSet(edgeData.map(edge => ({
      ...edge,
      width: edge.value * 1.5,
      arrows: "to",
      smooth: { type: "cubicBezier", forceDirection: "none", roundness: 0.5 }
    })));

    // 4. Initialize Vis Network
    const container = document.getElementById("network-container");
    const data = { nodes, edges };
    const options = {
      nodes: {
        borderWidth: 2,
        shadow: { enabled: true, color: "rgba(0,0,0,0.4)", size: 10, x: 0, y: 4 }
      },
      edges: {
        shadow: { enabled: false }
      },
      physics: {
        solver: "forceAtlas2Based",
        forceAtlas2Based: {
          gravitationalConstant: -100,
          centralGravity: 0.01,
          springLength: 150,
          springConstant: 0.08
        },
        stabilization: { iterations: 150 }
      },
      interaction: { hover: true, tooltipDelay: 100 }
    };

    const network = new vis.Network(container, data, options);

    // 5. Setup Side Inspector Event Listener
    network.on("selectNode", function (params) {
      const selectedId = params.nodes[0];
      const node = nodeData.find(n => n.id === selectedId);
      
      if (node) {
        document.getElementById("selected-name").innerText = node.label;
        document.getElementById("selected-type-badge").innerHTML = `<span class="badge" style="background:${colors[node.group]}; color:#000;">${node.group}</span>`;
        document.getElementById("selected-desc").innerText = node.desc || `${node.label} is a key ${node.group} node in the landscape ecosystem.`;

        // Filter and display connections
        const connections = edgeData.filter(edge => edge.from === selectedId || edge.to === selectedId);
        const connectionsList = document.getElementById("selected-connections");
        connectionsList.innerHTML = "";

        if (connections.length === 0) {
          connectionsList.innerHTML = '<div class="connection-item">No direct active connections mapped.</div>';
        } else {
          connections.forEach(edge => {
            const isOutgoing = edge.from === selectedId;
            const neighborId = isOutgoing ? edge.to : edge.from;
            const neighborNode = nodeData.find(n => n.id === neighborId);
            const directionText = isOutgoing ? "→" : "←";
            
            const item = document.createElement("div");
            item.className = "connection-item";
            item.innerHTML = `
              <div>
                <strong>${neighborNode.label}</strong>
                <div class="relation">${edge.label}</div>
              </div>
              <span style="font-weight:800; color:${colors[neighborNode.group]}">${directionText}</span>
            `;
            connectionsList.appendChild(item);
          });
        }
      }
    });

    network.on("deselectNode", function () {
      document.getElementById("selected-name").innerText = "Select an Entity";
      document.getElementById("selected-type-badge").innerHTML = "";
      document.getElementById("selected-desc").innerText = "Click any node in the landscape diagram to reveal its connections, role, and details here in the side inspector.";
      document.getElementById("selected-connections").innerHTML = "";
    });
  </script>
</body>
</html>
```

### Step 4 — Highlighting Key Discoveries
After saving the file, write a crisp, professional text analysis highlighting:
1. **Key Connectors (Centrality)**: Who has the highest degree?
2. **Structural Bottlenecks (Betweenness)**: Who connects separate clusters? If they disappear, does the network split?
3. **Runaway Risks**: Are too many critical dependencies concentrated on a single resource, person, or organization?
4. **Actionable Recommendations**: How can the user optimize this landscape map?

---

## Interaction Style

- **Extract data thoroughly first.** Map out the entities and connections clearly in your response so the user can verify the structure before opening the HTML.
- **Generate the HTML directly**. Do not write placeholders. Always output the complete, valid, self-contained HTML/CSS/JS file.
- **Add the HTML link**. Provide the link using the absolute file URI so they can easily click to view it.
- **Instruct clearly**. Tell the user exactly how to double-click and open the file in their browser.
