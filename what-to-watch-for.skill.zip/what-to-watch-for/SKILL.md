---
name: what-to-watch-for
description: >
  Use when the human has made a decision, formed a theory, or placed a bet on
  something and wants to know how to track whether they're right or wrong.
  Triggers: "how will I know if I'm right?", "what should I watch for?",
  "what would change my mind?", "how do I track this?", "what would prove me
  wrong?", "early warning signs", "leading indicators", "how will I know it's
  working?", "how do I monitor this?", "warning signs", "signals to watch",
  "what if I'm wrong?", "track my assumption", "reality check plan".
  Covers: business decisions, career moves, project bets, market predictions,
  relationship hypotheses, strategy validation, startup assumptions, investment
  theses — any situation where someone has a belief about the future and wants
  a structured way to watch reality for confirmation or contradiction.
---

# What to Watch For

Turn "I think X will happen" into a concrete watchlist of signals that tell you
whether you're right, wrong, or whether the situation is shifting underneath you.

## Core Idea

Every prediction — every decision based on what you *think* will happen — makes
hidden assumptions about the world. This skill makes those assumptions visible
and turns them into things you can actually observe and track.

Three categories of signals:

- **Confirmation signals**: What would I expect to see if I'm right?
- **Contradiction signals**: What would force me to reconsider?
- **Gaps**: What am I not tracking that I should be?

---

## Workflow

### Phase 1 — Clarify the Belief

Before generating signals, nail down exactly what the human believes.

Ask for or extract:

1. **The claim**: State the belief or decision as a clear, testable statement.
   - Weak: "I think this market is growing."
   - Strong: "I believe our SaaS product can capture 5% of the SMB accounting
     market within 18 months of launch."

2. **Time horizon**: By when should this play out? Open-ended beliefs are
   impossible to track.

3. **Confidence level**: How sure are they? Use plain language:
   - "I'm very confident" (~85%+)
   - "I think so, but I'm not certain" (~60-75%)
   - "It's roughly a coin flip" (~50%)
   - "It's a hunch" (~30-40%)

4. **What's at stake**: What rides on this being right? (Money, time, reputation,
   opportunity cost.) This determines how rigorous the monitoring should be.

If the human gives a vague claim, help them sharpen it. A good claim is specific
enough that in 6 months, you could look back and clearly say "yes, that happened"
or "no, it didn't."

### Phase 2 — Break the Belief Apart

Most beliefs are actually bundles of smaller assumptions. Decompose them.

**For each claim, ask:** What would have to be true for this to work?

Example — "My career switch to data science will pay off":
- Sub-claim 1: I can build sufficient skills in 12 months
- Sub-claim 2: The job market for data scientists stays strong
- Sub-claim 3: My prior domain experience is actually an advantage, not irrelevant
- Sub-claim 4: The pay increase offsets the transition cost

**Identify the driving forces:**
- What outside forces could push this toward success? (market trends, timing,
  tailwinds)
- What outside forces could push this toward failure? (competition, economic
  shifts, tech changes)

### Phase 3 — Generate the Watchlist (Four Quadrants)

This is the heart of the skill. For each sub-claim, generate signals in four
categories:

#### Quadrant 1: "Should See" (Confirming + Present)
*If I'm right, I should be seeing these things:*

Things whose **presence** would support your belief.

> Example: "If our product-market fit is real, I should see organic signups
> increasing month over month without extra ad spend."

#### Quadrant 2: "Shouldn't Be Seeing" (Contradicting + Present)
*If I'm right, these things should NOT be happening — but they are:*

Things whose **unexpected presence** is a warning sign.

> Example: "If our product-market fit is real, I should NOT be seeing high
> churn in the first 30 days — but we're at 40% monthly churn."

#### Quadrant 3: "Correctly Absent" (Confirming + Absent)
*If I'm right, I should NOT see these — and indeed I don't:*

Things whose **absence** supports your belief.

> Example: "If the market is truly underserved, I should NOT see well-funded
> competitors launching similar products — and so far, I don't."

#### Quadrant 4: "Missing in Action" (Contradicting + Absent)
*If I'm right, I SHOULD be seeing these — but I'm not:*

Things whose **unexpected absence** is a warning sign.

> Example: "If our content strategy is working, I SHOULD be seeing inbound
> leads from blog posts by now — but the pipeline is empty."

**Aim for 3-5 signals per quadrant per major sub-claim.** More for high-stakes
decisions, fewer for lower-stakes ones.

#### Signal Quality Checklist

For each signal, verify:

- [ ] **Observable**: Can I actually see/measure this? (Not "people like our
  product" but "NPS score above 40")
- [ ] **Timely**: Will this show up soon enough to act on? A signal that only
  appears after it's too late isn't useful.
- [ ] **Distinct**: Does this signal clearly point toward one conclusion? Or
  could it mean multiple things?
- [ ] **Independent**: Is this actually a separate signal, or just the same
  evidence dressed up differently?

### Phase 4 — Bias Check

Before finalizing, run a quick self-honesty check:

1. **Am I fooling myself?** Look at the watchlist — is it suspiciously tilted
   toward confirmation? Most people generate 3x more "should see" signals than
   "shouldn't be seeing" signals. Rebalance.

2. **Has an old guess become a "fact"?** (Creeping validity.) Check whether any
   of the sub-claims started as uncertain assumptions but are now being treated
   as settled truths. Flag them.

3. **Simplest explanation test** (Occam's Razor): Is there a much simpler
   explanation for what I'm seeing than the one I've built my belief around?
   If yes, add signals that would distinguish between the simple and complex
   explanations.

4. **Could I be misreading the signals?** For each key signal, briefly consider:
   what else could cause this signal to appear (or not appear) other than my
   theory being right/wrong?

### Phase 5 — Where to Look

For each signal, specify:

| Signal | Where to find it | How often to check | Current status |
|--------|------------------|--------------------|----------------|
| Organic signups rising | Analytics dashboard | Weekly | Not yet tracking |
| Competitor launches | Industry news, ProductHunt, Crunchbase | Monthly | No activity |
| Customer churn rate | Billing system | Weekly | 40% (concerning) |
| Inbound leads from content | CRM + attribution | Bi-weekly | Zero so far |

Sources to consider:
- **Numbers you already have**: dashboards, financials, analytics
- **Public information**: news, filings, job postings, social media, industry reports
- **People you can talk to**: customers, mentors, industry contacts, team members
- **Direct observation**: what you see with your own eyes in meetings, markets, etc.

Flag gaps explicitly: "I need this signal but I have no way to track it yet."

### Phase 6 — Build the Watchlist Summary

Output a clean, scannable summary:

```
## Watchlist: [Belief Statement]
Confidence: [level] | Time Horizon: [date] | Stakes: [what's at risk]

### Key Signals

#### ✅ Should See (confirms I'm right)
1. [Signal] — check [where], [how often]
2. ...

#### 🚩 Shouldn't Be Seeing (warns I'm wrong)
1. [Signal] — check [where], [how often]
2. ...

#### ✅ Correctly Absent (supports I'm right)
1. [Signal] — check [where], [how often]
2. ...

#### ⚠️ Missing in Action (warns I'm wrong)
1. [Signal] — check [where], [how often]
2. ...

### Gaps
- [What I can't currently track and why it matters]

### Check-in Schedule
- First review: [date]
- Regular cadence: [frequency]
- Hard deadline to reassess: [date]
```

### Phase 7 — Set Check-In Dates

A watchlist that never gets reviewed is useless. Help the human set:

1. **First review date**: Early enough to catch fast-moving signals (typically
   2-4 weeks out for business decisions, 1-3 months for career moves).

2. **Regular cadence**: How often to review the full watchlist. Match this to
   the pace of the situation:
   - Fast-moving (startup launch, market entry): weekly
   - Medium-pace (career transition, project rollout): bi-weekly or monthly
   - Slow-moving (industry trend, long-term investment): quarterly

3. **Hard reassessment deadline**: A date by which, if you haven't seen the
   key confirmation signals, you seriously reconsider the whole belief. This
   prevents indefinite "just give it more time" drift.

4. **Baseline snapshot**: Record what things look like RIGHT NOW, so you can
   detect changes later. Without a baseline, you can't tell if something is
   "increasing" or "decreasing."

---

## Important Principles

- **Contradiction signals are more valuable than confirmation signals.** It's
  easy to find evidence you're right. The real value is defining what would
  prove you wrong — and watching for it honestly.

- **Absence is evidence too.** "I expected X by now and it hasn't happened" is
  just as important as "Y happened and it shouldn't have."

- **Signals should be independent.** If three of your signals all come from
  the same data source or the same underlying cause, you effectively have one
  signal, not three. Diversify.

- **Watch for the slow drift.** The biggest risk isn't a sudden dramatic failure
  — it's the gradual shift where things are *slightly* off, month after month,
  until you're way off course. Set thresholds, not just directions.

- **Update the watchlist.** As you learn more, some signals become irrelevant
  and new ones emerge. The watchlist is a living document, not a one-time
  exercise.

---

## AI Role

- **Challenge the human's signal selection.** Push back if the watchlist is
  confirmation-heavy. Ask: "What signal would genuinely make you change your
  mind?"
- **Generate signals the human hasn't considered.** Especially contradiction
  signals and "missing in action" items — these are the hardest for people to
  come up with about their own beliefs.
- **Enforce observability.** Reject vague signals. "Market feels soft" → what
  specific metric would show that?
- **Flag redundancy.** Point out when signals are just measuring the same
  underlying thing twice.
- **Suggest check-in cadence** based on the stakes and time horizon.
- **The human brings judgment.** They know their context, their industry, their
  relationships. The AI brings structure, coverage, and the willingness to ask
  uncomfortable "what if you're wrong?" questions.
