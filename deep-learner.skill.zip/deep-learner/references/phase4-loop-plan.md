# Phase 4 — Loop Plan

> **Objective:** Turn the Gap List into a concrete, prioritized study plan — and set the
> conditions to run the Deep Learner cycle again. One pass is never mastery. The loop is
> the method.

---

## Role in this Phase: The Study Architect

You are helping the learner design their next learning session with precision. Not "go study
photosynthesis more" — but "here's what to do, in what order, for how long, and how to
know when you've filled each gap." The output should be specific enough that the learner
can execute it without Claude.

---

## Step 1: Match Gaps to Study Strategies

For each gap in the Gap List, recommend a specific study strategy based on its type.
Do not prescribe the same strategy for every gap.

| Gap Type | Best Strategy |
|----------|--------------|
| **Missing Piece** | Direct input — read a focused source, watch a specific video, ask a targeted question. The learner needs new information they simply don't have yet. Recommend a search query or source type, not just "look it up." |
| **Broken Link** | Connection-building — draw a diagram connecting A to B. Write 3 sentences that *only* describe the handoff between the two concepts. Then explain it out loud to themselves. |
| **False Confidence** | Deliberate correction — first write down their current (wrong) model in full. Then find the accurate version. Then write a paragraph explaining specifically *where* their model was wrong and *why* the correct version works. Don't just replace the wrong version — interrogate it. |
| **Shallow Retrieval** | Generation practice — cover the definition and try to write it from scratch. Then check. Then try again 10 minutes later. Spaced retrieval, not re-reading. |

---

## Step 2: Sequence the Work

Order the gaps by priority and dependency. Foundational gaps (things other gaps depend on)
come first, regardless of the learner's preference.

Present a sequenced study plan:

```
LOOP PLAN — NEXT SESSION
─────────────────────────
Topic: [topic]
Session goal: Fill [N] gaps from this cycle

Session structure:
  [Time estimate] total — break into blocks if needed

Block 1 — [Gap name, High priority]
  Strategy: [Specific action from the table above]
  What to do: [2–3 sentences of concrete instruction]
  Done when: [How will the learner know this gap is filled? What should they be able to do?]

Block 2 — [Gap name]
  Strategy: [...]
  What to do: [...]
  Done when: [...]

[Repeat for each gap being targeted this session]

Lower priority gaps (saved for next loop):
  - [Gap name] — [one-line reason it's deferred]
```

---

## Visual Output — Study Plan Dashboard

After presenting the Loop Plan text, generate a self-contained `study_plan.html` file and
save it to the workspace. This gives the learner a standalone, interactive dashboard they
can open in any browser and work through as they study — without needing Claude.

**What to build:** A three-column kanban board (To Study → In Progress → Done) with one
card per study block. Each card shows the gap name, strategy type, concrete instructions,
and a "Done when" condition. Cards are draggable between columns so the learner can track
their own progress.

**Card accent colors by gap type** (match the gap map from Phase 3):
- `#D0021B` — Missing Piece
- `#EF6C00` — Broken Link
- `#F5A623` — False Confidence
- `#4A90E2` — Shallow Retrieval

**Template to follow exactly** (replace placeholder data with the real Loop Plan):

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Study Plan</title>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;800&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg: #0f172a; --col: rgba(30,41,59,0.7); --border: rgba(255,255,255,0.08);
      --text: #f8fafc; --sub: #94a3b8; --accent: #3b82f6;
      --done-bg: rgba(16,185,129,0.08); --done-border: rgba(16,185,129,0.25);
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Outfit', sans-serif; background: var(--bg); color: var(--text);
           min-height: 100vh; padding: 32px 24px; }
    header { margin-bottom: 32px; }
    header h1 {
      font-size: 26px; font-weight: 800; letter-spacing: -0.5px;
      background: linear-gradient(135deg, #60a5fa, #3b82f6);
      -webkit-background-clip: text; -webkit-text-fill-color: transparent;
      margin-bottom: 6px;
    }
    header p { font-size: 13px; color: var(--sub); }
    .meta { display: flex; gap: 24px; margin: 16px 0 32px; flex-wrap: wrap; }
    .meta-chip {
      background: rgba(255,255,255,0.05); border: 1px solid var(--border);
      border-radius: 20px; padding: 6px 14px; font-size: 12px; color: var(--sub);
    }
    .meta-chip strong { color: var(--text); }
    .board { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
    .column {
      background: var(--col); backdrop-filter: blur(12px);
      border: 1px solid var(--border); border-radius: 16px;
      padding: 20px; min-height: 400px;
    }
    .column.done { background: var(--done-bg); border-color: var(--done-border); }
    .col-header {
      font-size: 10px; font-weight: 800; text-transform: uppercase;
      letter-spacing: 1.5px; margin-bottom: 16px; display: flex;
      align-items: center; gap: 8px;
    }
    .col-count {
      background: rgba(255,255,255,0.1); border-radius: 20px;
      padding: 2px 8px; font-size: 11px; font-weight: 600; color: var(--sub);
    }
    .card {
      background: rgba(255,255,255,0.04); border: 1px solid var(--border);
      border-radius: 12px; padding: 16px; margin-bottom: 12px;
      cursor: grab; transition: transform 0.15s, box-shadow 0.15s;
      border-left: 3px solid var(--accent);
      user-select: none;
    }
    .card:active { cursor: grabbing; transform: scale(1.02);
                   box-shadow: 0 12px 30px rgba(0,0,0,0.4); }
    .card.dragging { opacity: 0.4; }
    .column.drag-over { border-color: var(--accent); background: rgba(59,130,246,0.08); }
    .card-title { font-size: 14px; font-weight: 700; margin-bottom: 6px; }
    .strategy-badge {
      display: inline-flex; align-items: center; padding: 3px 10px;
      border-radius: 20px; font-size: 10px; font-weight: 700;
      margin-bottom: 10px; color: #000;
    }
    .card-instructions { font-size: 12px; color: var(--sub); line-height: 1.6; margin-bottom: 10px; }
    .done-when {
      background: rgba(255,255,255,0.04); border-radius: 8px;
      padding: 8px 10px; font-size: 11px; color: var(--sub); line-height: 1.5;
    }
    .done-when::before {
      content: "✓ Done when: "; font-weight: 700; color: #10b981;
    }
    .column.done .card { opacity: 0.6; }
    .reentry {
      margin-top: 32px; background: var(--col); backdrop-filter: blur(12px);
      border: 1px solid var(--border); border-radius: 16px; padding: 24px 28px;
    }
    .reentry h3 {
      font-size: 10px; font-weight: 800; text-transform: uppercase;
      letter-spacing: 1.5px; color: var(--accent); margin-bottom: 12px;
    }
    .reentry p { font-size: 14px; color: var(--sub); line-height: 1.7; }
    .reentry strong { color: var(--text); }
    .first-action {
      margin-top: 16px; background: rgba(59,130,246,0.08);
      border: 1px solid rgba(59,130,246,0.25); border-radius: 12px;
      padding: 16px 18px; font-size: 13px; color: var(--text); line-height: 1.6;
    }
    .first-action::before {
      display: block; content: "⚡ Do this first (next 20 min)";
      font-size: 10px; font-weight: 800; text-transform: uppercase;
      letter-spacing: 1.2px; color: #60a5fa; margin-bottom: 8px;
    }
    @media (max-width: 700px) { .board { grid-template-columns: 1fr; } }
  </style>
</head>
<body>

<header>
  <h1 id="plan-title">Study Plan</h1>
  <p>Drag cards between columns as you work through each gap.</p>
  <div class="meta">
    <div class="meta-chip">Topic: <strong id="topic-label">—</strong></div>
    <div class="meta-chip">Session goal: <strong id="goal-label">—</strong></div>
    <div class="meta-chip">Est. time: <strong id="time-label">—</strong></div>
  </div>
</header>

<div class="board">
  <div class="column" id="col-todo"   data-col="todo">
    <div class="col-header" style="color:#60a5fa">
      To Study <span class="col-count" id="count-todo">0</span>
    </div>
  </div>
  <div class="column" id="col-doing"  data-col="doing">
    <div class="col-header" style="color:#f59e0b">
      In Progress <span class="col-count" id="count-doing">0</span>
    </div>
  </div>
  <div class="column done" id="col-done" data-col="done">
    <div class="col-header" style="color:#10b981">
      Done <span class="col-count" id="count-done">0</span>
    </div>
  </div>
</div>

<div class="reentry">
  <h3>Re-entry Signal</h3>
  <p id="reentry-text">—</p>
  <div class="first-action" id="first-action-text">—</div>
</div>

<script>
  // ── DATA (replace with real Loop Plan from this session) ─────────────────
  const PLAN = {
    topic:       "TOPIC_NAME_HERE",
    sessionGoal: "Fill N gaps from this cycle",
    estTime:     "X hours",
    reentry:     "You're ready to run the next cycle when you can explain [topic] to an imaginary 10-year-old without pausing…",
    firstAction: "Open a blank document and write down, from memory, [specific action]. Don't look anything up. This is your baseline for Block 1."
  };

  const blocks = [
    {
      id: "b1",
      gapName:      "Gap name here",
      gapType:      "Missing Piece",     // Missing Piece | Broken Link | False Confidence | Shallow Retrieval
      strategy:     "Direct input",
      instructions: "2–3 sentences of concrete instructions.",
      doneWhen:     "What the learner can do once this gap is filled.",
      priority:     "High"               // High | Medium | Low — determines initial column order
    },
    // … add one object per study block
  ];

  // ── COLOR MAP ─────────────────────────────────────────────────────────────
  const typeColor = {
    "Missing Piece":    "#D0021B",
    "Broken Link":      "#EF6C00",
    "False Confidence": "#F5A623",
    "Shallow Retrieval":"#4A90E2"
  };

  // ── POPULATE HEADER ───────────────────────────────────────────────────────
  document.getElementById("plan-title").textContent   = PLAN.topic + " — Study Plan";
  document.getElementById("topic-label").textContent  = PLAN.topic;
  document.getElementById("goal-label").textContent   = PLAN.sessionGoal;
  document.getElementById("time-label").textContent   = PLAN.estTime;
  document.getElementById("reentry-text").textContent = PLAN.reentry;
  document.getElementById("first-action-text").textContent = PLAN.firstAction;

  // ── BUILD CARDS ───────────────────────────────────────────────────────────
  const state = {}; // cardId → column

  blocks.forEach(b => {
    state[b.id] = "todo";
    const card = document.createElement("div");
    card.className = "card";
    card.id = b.id;
    card.draggable = true;
    card.style.borderLeftColor = typeColor[b.gapType] || "#3b82f6";
    card.innerHTML = `
      <div class="card-title">${b.gapName}</div>
      <span class="strategy-badge" style="background:${typeColor[b.gapType]||'#3b82f6'}">${b.strategy}</span>
      <div class="card-instructions">${b.instructions}</div>
      <div class="done-when">${b.doneWhen}</div>
    `;
    card.addEventListener("dragstart", e => {
      e.dataTransfer.setData("text/plain", b.id);
      setTimeout(() => card.classList.add("dragging"), 0);
    });
    card.addEventListener("dragend", () => card.classList.remove("dragging"));
    document.getElementById("col-todo").appendChild(card);
  });

  // ── DRAG-AND-DROP ─────────────────────────────────────────────────────────
  document.querySelectorAll(".column").forEach(col => {
    col.addEventListener("dragover", e => { e.preventDefault(); col.classList.add("drag-over"); });
    col.addEventListener("dragleave", () => col.classList.remove("drag-over"));
    col.addEventListener("drop", e => {
      e.preventDefault();
      col.classList.remove("drag-over");
      const id = e.dataTransfer.getData("text/plain");
      const card = document.getElementById(id);
      if (card) { col.appendChild(card); state[id] = col.dataset.col; updateCounts(); }
    });
  });

  function updateCounts() {
    ["todo","doing","done"].forEach(c => {
      document.getElementById("count-"+c).textContent =
        document.getElementById("col-"+c).querySelectorAll(".card").length;
    });
  }
  updateCounts();
</script>
</body>
</html>
```

**How to generate the file:**
1. Fill in `PLAN` with the topic, session goal, estimated time, re-entry signal (from Step 3),
   and first action (from Step 4) from this session
2. Fill in `blocks` with one object per study block from the Loop Plan — use the exact gap
   names, types, strategies, concrete instructions, and "done when" conditions from Step 2
3. Save the completed file as `study_plan.html` in the workspace
4. Share it using `present_files`

After sharing the file, say:
> "Here's your study plan dashboard — open it in a browser and drag cards to 'In Progress'
> as you start each block, then to 'Done' when you've filled that gap."

---

## Step 3: Set the Re-entry Condition

The learner should know exactly when to run the Deep Learner cycle again on this topic.
Give them a clear trigger:

> "You're ready to run the next cycle when you can explain [topic] to an imaginary 10-year-old
> without pausing, without using [key jargon term] unexplained, and without hesitating on the
> connection between [A] and [B]. That's your re-entry signal."

Tailor this to the specific topic and the gaps found. Make it concrete, not vague.

---

## Step 4: One Thing to Do in the Next 20 Minutes

The biggest enemy of a study plan is delay. Give the learner one small, specific thing they
can do *right now* to start:

> "Before you close this conversation — one thing. [Specific action: e.g., 'Open a blank
> document and write down, from memory, the sequence of steps in the Calvin cycle. Don't
> look anything up. This is your baseline for Block 1.'] It'll take 5 minutes. Do it now."

This matters. A study plan that starts immediately is 10x more likely to actually happen.

---

## Step 5: The Perkins Check

Before closing, run one final check drawn from Perkins' "Playing the Whole Game":

Ask the learner:
> "One last question: where would you actually *use* what you're learning? Not in an exam —
> in real life, in a conversation, in another subject, in a problem you care about. Can you
> name one place this knowledge would matter?"

This anchors the learning to transfer. If the learner can't answer, that's a signal the
"why it matters" needs more work — note it and add it to the next loop.

---

## Phase Gate Summary (Closing)

Present the full Loop Plan, then close the cycle:

**"Deep Learner cycle complete. Schedule your next session targeting the gaps we named.
The loop is what builds mastery — one pass is never enough."**

Then offer:
> "Want to run the next loop now on any of these gaps? Or save this plan and come back
> when you've done the study work?"
