---
name: scenario-builder
description: >
  AI-assisted scenario planner. Use this skill whenever someone wants to plan for multiple plausible
  futures instead of just betting on the single outcome they expect or hope for. Helps weigh the forces
  pushing for and against change, understand how they interact, and build 3 distinct scenarios: Status
  Quo, Gradual Shift, and Wild Card. Triggers include phrases like "what could happen?", "help me plan for
  different outcomes", "scenario planning", "what if things go wrong?", "what are the possibilities?",
  "best case worst case", or requests to model a major decision.
---

# Scenario Builder

## What This Does
When facing a big change or a high-stakes decision, it is easy to fall into straight-line thinking — assuming tomorrow will look just like today, or betting everything on your dream outcome. 

This skill uses **Force Field Analysis** to map the tension between forces pushing for change and forces resisting it. By understanding this balance, you can prepare for 3 distinct futures: the Status Quo, a Gradual Shift, and a Wild Card disruption.

## Roles
The human is the decision-maker who brings context, goals, and values. Claude is the systems modeler and scenario architect. Claude does NOT replace your judgment. Claude:
1. **Identifies the Forces**: Helps you list and categorize what is pushing for change (Disruptive Forces) and what is holding things back (Cohesive Forces).
2. **Weighs the Tension**: Assigns scores to the forces to see how stable the current situation actually is.
3. **Maps the Dynamic Reactions**: Anticipates lag times, synergy swarms, and the natural pushback that any change triggers.
4. **Drafts 3 branch paths**: Details how different scenarios would play out so you have a playbook for each.
5. **Generates Tripwires**: Identifies "what to watch for" so you know which future is actually happening before it's too late.

## Flexible Entry Points

| What you bring | What Claude does |
|---|---|
| A big decision or transition | Define the focal question, propose pushing/resisting forces, and guide you through weighting them |
| Draft scenario descriptions | Reverse-engineer the underlying forces, check for straight-line bias, and build the Force Field Matrix |
| A list of forces | Organize them into categories, calculate stability, and construct 3 distinct scenario narratives |

---

## Phase 1 — Define the Question & Identify the Forces

### The Focal Question
State the transition as a clear question with a specific timeline (e.g., "Will our team successfully transition to a remote-first model in the next 6 months?" or "Will I be able to launch this side project while keeping my day job?").

### Grouping the Forces
Brainstorm the forces at play. To ensure you don't miss anything, group them into civilian categories:
- 📈 **Market/Context Forces** (competitors, demand, economic climate)
- ⚙️ **Technology & Operations** (tools, bandwidth, technical skills)
- ⚖️ **Rules & Regulations** (policies, contracts, laws)
- 👥 **Culture & Relationships** (morale, team dynamics, family support)
- 💰 **Finances & Resources** (budget, savings, runway)

Categorize them into two camps:
1. **Forces Pushing for Change (Disruptive)**: What is driving the system to transition?
2. **Forces Resisting Change (Cohesive/Inertia)**: What is holding the system in its current state?

---

## Phase 2 — The Force Field Matrix & Stability Score

Build the Force Field Matrix to weigh the tension:

1. **Assign Strengths**: Rate the strength of each force from **1** (barely noticeable) to **10** (completely dominant).
2. **Calculate the Net Balance**: Total the scores of the Pushing Forces vs. the Resisting Forces.
3. **Determine the Stability Level**:
   - 🟢 **Stable Equilibrium**: Resisting forces vastly overpower or perfectly balance stable pushing forces. Change is highly unlikely without a massive new trigger.
   - 🟡 **Tipping Point (Volatile)**: Forces are highly balanced but volatile. A tiny nudge or minor event will trigger a sudden, massive shift.
   - 🔴 **Active Transition**: Pushing forces actively overpower resisting forces. The system is already changing, and there's no going back.

---

## Phase 3 — The Dynamic Reactions Audit

Systems aren't static. When you push on a system, it pushes back. Audit these four dynamic patterns:

1. **The Reaction Cycle (Pushback)**: What reactive, offsetting force will emerge as a direct result of your change? (e.g., If you launch a new feature, how quickly will your competitor copy it or drop their prices?).
2. **Synergy Swarms**: Which forces might combine to amplify each other? (e.g., Low morale + a financial crunch can combine to trigger a sudden wave of resignations).
3. **Lag Times**: What changes will have a delayed reaction? (e.g., Cutting marketing spend saves money today, but the drop in sales might not hit for 3 months).
4. **Bad Habits Spread (Contamination)**: What lazy shortcuts or poor behaviors might seep into the system as change occurs?

---

## Phase 4 — Branching Scenario Narratives

Draft three distinct futures:

### Scenario 1: Status Quo (Inertia Wins)
- *Storyline*: Resisting forces dominate, or pushing forces burn out. Everything stays roughly the same.
- *What it looks like*: Describe this day-to-day reality in detail.
- *Tripwires*: What clues show you are locked in this path?

### Scenario 2: Gradual Shift (Evolutionary)
- *Storyline*: Pushing forces steadily erode resistance, leading to a planned, gradual transition to a new normal.
- *What it looks like*: The most likely path of successful change.
- *Tripwires*: What milestones indicate steady progress?

### Scenario 3: Wild Card (Disruption/Black Swan)
- *Storyline*: A highly volatile, external force completely shatters the balance, triggering a rapid, chaotic transition.
- *What it looks like*: The chaotic, unexpected, or worst-case path.
- *Tripwires*: What early-warning signs tell you the ground is shifting?

---

## Phase 5 — The Scenario Report Template

```markdown
# Scenario Analysis: [Focal Question]

## 1. The Stability Verdict
- **Net Causal Balance**: [Pushing Dominant | Resisting Dominant | Balanced Volatile]
- **Stability Rating**: [Stable | Could Tip Either Way | Already Changing]
- **Leading Scenario Path**: [Status Quo | Gradual Shift | Wild Card]

## 2. The Force Field Matrix
| Forces Resisting Change (Stability) | Weight | Forces Pushing for Change (Transition) | Weight |
|---|---|---|---|
| [Force A] | [Score] | [Force X] | [Score] |
| [Force B] | [Score] | [Force Y] | [Score] |
| **TOTAL RESISTING** | **[Sum]** | **TOTAL PUSHING** | **[Sum]** |

## 3. Dynamic Reactions & Lags
- **The Reaction Cycle**: [Expected pushback/offsetting responses]
- **Synergy Swarms**: [Combinations of forces that amplify each other]
- **Lag Times & Lags**: [Delayed effects to watch out for]

## 4. Branching Scenarios
### Scenario 1: Status Quo
- *The Narrative*: [Detailed storyline]
- *Tripwires (What to watch for)*: [Specific signposts]

### Scenario 2: Gradual Shift
- *The Narrative*: [Detailed storyline]
- *Tripwires (What to watch for)*: [Specific signposts]

### Scenario 3: Wild Card
- *The Narrative*: [Detailed storyline]
- *Tripwires (What to watch for)*: [Specific signposts]
```
