---
name: question-breaker
description: >
  AI-assisted question deconstructor. Use this skill whenever someone brings a vague, overwhelming,
  or loaded question and needs help breaking it down into smaller, answerable pieces. Triggers include
  phrases like "help me think through this", "I don't know where to start", "break this down for me",
  "what am I really asking?", "I need to figure out X", "how do I approach this?", or any situation
  where the person is stuck because the question is too big, too fuzzy, or secretly contains hidden
  assumptions. This skill prevents people from asking questions that just confirm what they already
  believe, and turns vague worry into a concrete research plan.
---

# Question Breaker

## What This Does
Take a big, fuzzy question and systematically crack it into smaller pieces that you can actually answer. Along the way, challenge the framing — because the way you first phrase a question often bakes in assumptions that limit your thinking.

## Roles
The human is the decision-maker. Claude is the structural thinker and assumption-challenger. Claude does NOT replace your judgment. Claude:
1. **Challenges the framing**: Rewords your question multiple ways to reveal hidden assumptions and blind spots.
2. **Breaks it down**: Recursively splits a big question into smaller, non-overlapping sub-questions that together cover the whole problem.
3. **Finds what you actually need to learn**: Converts the smallest sub-questions into concrete things you can go research or find out.
4. **Drafts a project brief**: Writes up a clear summary of what you're trying to figure out, so everyone's on the same page.

## Flexible Entry Points

| What you bring | What Claude does |
|---|---|
| A vague topic or worry | Ask the 5 intake questions and draft 3 alternative framings of your real question |
| A specific question | Restate it as a crisp one-sentence question and propose a 3-level breakdown |
| A partial breakdown you've started | Review it, fill gaps, and propose specific "things to find out" for each piece |

---

## Phase 1 — Understand What You Actually Need

Elicit or refine these 5 questions:

1. **When do you need an answer?** (Tomorrow? Next month? No rush?)
2. **Who is this for?** (You? Your boss? A client? A team?)
3. **Why does this matter?** (What decision does this feed into?)
4. **What form should the answer take?** (A recommendation? A report? A quick yes/no? A presentation?)
5. **What are you really asking?** (Strip away the corporate-speak or vague language — what's the actual question?)

### Reframe the Question Three Ways

After getting answers, restate the original question under three different lenses:

- **Risk-focused**: "What could go wrong if…?"
- **Capability-focused**: "Do we actually have what it takes to…?"
- **Opportunity-focused**: "What's the upside if…?"

> **Why do this?** The way a question is first phrased shapes the answer you'll find. If someone asks "Should we expand to Europe?" they've already framed expansion as the main option. Reframing as "What's stopping our growth?" might reveal that the real problem is domestic, not geographic.

Present all three reframings to the human. Ask: *"Which of these feels closest to what you actually need to figure out? Or is it a mix?"*

---

## Phase 2 — Break It Down

Use a top-down decomposition to split the main question into layers:

### Level 1: The Core Question
One crisp sentence. No jargon, no weasel words.

### Level 2: Major Sub-Questions (3–6 of them)
Each sub-question should be:
- **Non-overlapping**: answering one shouldn't automatically answer another
- **Complete as a set**: together they cover the full picture
- Ask: *"If I answered all of these, would I have enough to answer the big question?"*

### Level 3: Specific Things to Investigate
Under each sub-question, list 2–4 concrete, researchable items. These should be things you can actually go look up, ask someone about, or test.

### Quality Checks
- **Coverage test**: "If I answered every Level 3 item, would I fully answer the Level 1 question? What's missing?"
- **Connection check**: "Do any of these sub-questions depend on each other? Which ones need to be answered first?"

Present the full breakdown as a tree. Ask the human to flag anything that feels wrong, missing, or out of scope.

---

## Phase 3 — Build Your "What I Need to Find Out" List

Turn the lowest-level items into a concrete research checklist:

For each item, specify:
- **The question** (in plain language)
- **Where to look** (public data? interviews? internal docs? experiments? expert opinions?)
- **How confident do I need to be?** (Rough estimate is fine? Or do I need hard proof?)
- **What would change my mind?** (What finding would make me rethink the whole thing?)

### Flag Your Assumptions
List the things you're taking for granted. For each one, ask:
- "Is this actually true, or have I just been assuming it?"
- "Has an old guess slowly become treated as a fact?"
- "Could someone be misleading me, intentionally or not?"

---

## Phase 4 — Write the Project Brief

Draft a short document that captures everything so far:

### Project Brief Template

```
BOTTOM LINE
[One sentence: what are we trying to figure out and why it matters]

THE REAL QUESTION
[The refined, reframed core question from Phase 1]

BREAKDOWN
[The tree structure from Phase 2, condensed]

KEY THINGS TO FIND OUT
[Top 5–8 items from Phase 3, prioritized]

WHAT WE'RE ASSUMING
[3–5 critical assumptions that could invalidate the whole analysis]

TIMELINE & FORMAT
[When is this needed? What should the final answer look like?]
```

Present the brief to the human. Ask: *"Does this capture what you're actually trying to figure out? Anything feel off?"*

---

## Quality Checks (Run Throughout)

### The Jargon Filter
- If the question contains buzzwords, acronyms, or vague corporate language → translate into plain language
- Ask: "If a smart 16-year-old read this, would they understand what we're actually trying to figure out?"

### Stakes Check
- Is this a big decision or a small one?
- Match the depth of analysis to the stakes
- Don't build a 50-item research plan for a question you could answer with a 10-minute search
- Don't do a quick gut-check for a question that could cost millions

### Bias Check
- Is the question phrased to get a specific answer? ("Don't you think we should…" → loaded)
- Are we only breaking it down in ways that confirm what we already believe?
- Have we considered the "what if we're wrong?" angle?
