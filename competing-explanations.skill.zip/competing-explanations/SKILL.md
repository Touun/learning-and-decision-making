---
name: competing-explanations
description: >
  AI-assisted Analysis of Competing Explanations. Use this skill whenever someone wants to evaluate
  multiple plausible explanations for a situation, check which ones the evidence actually supports, and
  eliminate confirmation bias by focusing on what DISPROVES each explanation rather than what confirms
  it. Triggers include phrases like "what's really going on here?", "I can't figure out why X is happening",
  "am I seeing this right?", "what are the possible explanations?", "help me evaluate these options",
  "competing theories", or any request to compare multiple options or explanations side-by-side.
---

# Competing Explanations

## What This Does
When you're trying to figure out a messy situation, confirmation bias is your biggest enemy. It makes you latch onto a favorite theory and only look for evidence that proves you right. 

This skill forces you to do the opposite: **line up all plausible explanations, and focus on what DISPROVES them.** The explanation that survives with the fewest contradictions is your most robust bet.

## Roles
The human is the decision-maker who brings context, judgment, and gut checks. Claude is the cognitive partner and structured challenger. Claude does NOT replace your judgment. Claude:
1. **Helps map explanations**: Ensures you have a healthy set of 3–5 different possibilities to compare.
2. **Structures the evidence**: Gathers facts, assumptions, and absences in one clear place.
3. **Populates the matrix**: Builds a Competing Explanations Table and scores how evidence fits each explanation.
4. **Flags what matters (Diagnostics)**: Highlights the specific pieces of evidence that actually help you decide, and filters out the noise.
5. **Challenges the leading theory**: Acts as a red-team partner, asking "What would have to be true for this to be wrong?"

## Flexible Entry Points

| What you bring | What Claude does |
|---|---|
| A messy situation/problem | Propose 3–5 alternative explanations, and ask you to select or edit them |
| A problem + a list of theories | Help you gather and structure evidence, or suggest candidate evidence items |
| A problem + theories + evidence | Go straight to populating the Competing Explanations Table and scoring |
| A finished table | Skip to challenging the conclusion, sensitivity audits, and drafting the report |

---

## Phase 1 — Frame the Situation

Extract or refine:
- **The Core Mystery**: What are you trying to explain or predict?
- **The Context**: Who is involved? What is the timeframe?
- **The Stakes**: What decision does this inform? (Helps calibrate depth)

---

## Phase 2 — Draft the Explanations

### Guidelines for Explanations
- **Mutually Exclusive**: Try to make them distinct so they don't overlap too much.
- **Declarative**: State them as clear possibilities (e.g., "Explanation 1: The competitor is launching a copycat product" rather than "Are they copying us?").
- **A Diverse Set**: Aim for 3–5 explanations. Always include:
  - The leading guess (your favorite)
  - A benign/coincidence explanation
  - An uncomfortable or worst-case option

### Socratic Check
Before proceeding, Claude will ask:
> *"Are you happy with these explanations, or do you want to add, remove, or adjust any of them before we build our matrix?"*

---

## Phase 3 — Gather the Evidence

Collect observed facts, expert opinions, customer feedback, and missing clues.

### What Counts as Evidence
- **Observed facts**: "Website traffic fell by 14% this week."
- **Opinions/Quotes**: "The sales director thinks pricing is too high."
- **Absences (Missing Clues)**: "No one has complained about bugs, despite the traffic drop."

### Auditing Your Evidence
Run your evidence through three quick filters:
1. **The Photocopy Test (Source Check)**: Did you observe this firsthand, or is it hearsay? (Information degrades every time it is passed along).
2. **Zombie Facts (Creeping Validity)**: Are you sure this is a fact? Or was it originally a guess that everyone started repeating until it felt like a fact?
3. **The Echo Chamber Check (Redundancy)**: Are three different articles citing the exact same single press release? If so, merge them so they don't artificially skew your scoring.

---

## Phase 4 — Build the Competing Explanations Table

### The Scoring Scheme
For every cell where Evidence meets an Explanation, assign a score:

| Score | Meaning | Visual Code |
|---|---|---|
| **C** | **Consistent**: Fits this explanation perfectly (but might fit others too). | Blue |
| **I** | **Inconsistent**: Strongly contradicts this explanation. Makes it less likely. | Red |
| **N/A** | **Not Applicable**: This evidence has no bearing on this explanation. | Gray |
| **?** | **Unknown**: We don't have enough info to know if it fits. | Yellow |

> **IMPORTANT**: The magic of this method is **disconfirmation**. We are looking for **Red cells (Inconsistent)**. The theory with the most Red cells is the most fragile. The one with the fewest is the most robust.

### Diagnostic Tagging
Once scored, tag each piece of evidence:
- 🔴 **Highly Diagnostic**: Scores differently across explanations (e.g., C for E1, but I for E2). **This is your gold standard** — it helps you make a decision.
- 🟡 **Weakly Diagnostic**: Inconsistent for one theory, but consistent/gray for others.
- ⚪ **Non-Diagnostic**: Scores the same (all C or all N/A) across all theories. **This is noise.** It fits everything, so it eliminates nothing. Flag these and stop over-relying on them.

---

## Phase 5 — The Decision Matrix (React Table)

Generate an interactive Competing Explanations Table. The table must feature:
- Color-coded cells for rapid visual scanning (C = Blue, I = Red, N/A = Gray, ? = Yellow).
- A **Diagnostic Rating** column (🔴/🟡/⚪) showing which clues actually help you decide.
- A **Credibility Bar** at the bottom showing the count of **I (Inconsistent)** scores for each explanation. The fewer inconsistencies, the higher the credibility.

---

## Phase 6 — Stress-Test Your Thinking

Claude must challenge your table with these five checks:

1. **The Surviving Champion**: Which explanation has the fewest inconsistencies? Is it your original favorite, or did another explanation survive because it's quietly more solid?
2. **Noise Audit**: Highlight the ⚪ non-diagnostic items. *"You've spent a lot of time tracking these clues, but they fit every theory. They're making you feel confident without actually helping you decide."*
3. **The Linchpin Challenge (Sensitivity Test)**: Find the single diagnostic clue that holds your leading theory together. *"Your conclusion depends heavily on Clue [E1]. If [E1] turns out to be incorrect or a rumor, Explanation [E2] immediately becomes your most likely scenario. How certain are you of this clue?"*
4. **Occam's Razor**: If E1 and E2 are close, which one requires the fewest unproven assumptions? The simpler explanation is usually the better bet.
5. **The Drama Tax**: Are you giving too much weight to a highly dramatic or recent event (like a bad tweet) while ignoring quieter, more solid data (like monthly user retention)?

---

## Phase 7 — The Project Brief

Write up a clean, printable summary of the analysis:

```
=========================================
COMPETING EXPLANATIONS PROJECT BRIEF
=========================================

THE CORE MYSTERY
[What you are trying to explain/decide]

PLAUSIBLE THEORIES
E1: [Title] - [Brief desc]
E2: [Title] - [Brief desc]
E3: [Title] - [Brief desc]

DECISION TABLE
[Render a clean text table of the matrix]

CREDIBILITY SUMMARY
- E1: [N] inconsistencies (Leading)
- E2: [N] inconsistencies
- E3: [N] inconsistencies

THE GOLD-STANDARD CLUES (DIAGNOSTIC)
- [Clue A]: Eliminates E2 because [reason]
- [Clue B]: Eliminates E3 because [reason]

THE LINCHPIN (What holds the conclusion together)
- [Clue X]: If this is wrong, the whole conclusion flips to E2.

WHAT TO WATCH FOR (Future Signposts)
- [Signpost 1]: If we observe this in the next 2 weeks, it proves E1 is correct.
- [Signpost 2]: If we observe this, it signals a shift to E2.
```
